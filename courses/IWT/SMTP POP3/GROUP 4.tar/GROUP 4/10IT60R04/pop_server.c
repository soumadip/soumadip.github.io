
//mount -t nfs 10.14.1.102:/home/user/IWT/Assign7/mails /root/Desktop/mails/
/* pop server prog */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<ctype.h>

/* The following three files must be included for network programming */
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

/*For shared memory and semaphore*/
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/sem.h>

/* For signal handling */
#include <unistd.h>
#include <errno.h>
#include <signal.h>
#include<sys/file.h>

/* functions definitions*/ 
#define server_ip "10.14.1.109"
#define server_port 62105
#define user 5
#define msg_size 100
#define name_len 20
#define path_len 40
#define line_len 100
#define usertext "/root/Desktop/mails/user.txt"
#define mailbox_path "/root/Desktop/mails/"

int Is_a_cmd(char*,int,char*);
int stat_call(char*,int*,int*);
char* in_to_str(int,char *);
int str_to_int(char *,char *);
void send_mail(char *,int ,int );
int del_call(int ,char*);
int quit_call(char *);
int rest_call(char*);
int list_call_no(char *,int,int*);

int main()
{
	int sockfd, newsockfd ;
	int flag=1,i=0,j,recv_val,stat_val, user_flag=0,pass_flag=0,list_val,demand;
	int no_mail,no_oct;
	char *no_of_mail, *no_of_oct,*str;
	char msg[msg_size],send_msg[msg_size],last_ch[3],end_dl[3];
	char user_name[name_len],user_pass[name_len];
	struct sockaddr_in cli_addr, serv_addr;
	socklen_t	clilen;

	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0))<0)
	{
		perror("perror :socket can't be created\n");	
		exit(1);
	}
	
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = inet_addr(server_ip);
	serv_addr.sin_port = htons(server_port);

	if(bind(sockfd,(struct sockaddr*)&serv_addr, sizeof(serv_addr))<0)
	{
		perror("perror can't bind\n");
		exit(1);
	}
	

	listen(sockfd,1);
	clilen = sizeof(cli_addr);
	
	end_dl[0]='\r';
	end_dl[1]='\n';
	end_dl[2]='\0';

	while(1)
	{		
		newsockfd = accept(sockfd, (struct sockaddr *)&cli_addr, &clilen);
		if(newsockfd<0)
		{
			printf("error in accept...\n");
			exit(0);
		}		
		if (fork()==0)
		{	
			close(sockfd);
			strcpy(send_msg,"+OK POP3 server ready");
									//<CRLF> char handling
			i=strlen(send_msg);
			send_msg[i]='\r';
			send_msg[i+1]='\n';
			send_msg[i+2]='\0';
			i=0;
			send(newsockfd,send_msg,strlen(send_msg),0);	//send +OK POP3 server ready
			
			while(flag)
			{
				memset(msg,'\0',msg_size);
				i=0;
				strcpy(last_ch,"ab");
				recv_val=1;
				while(/*i < msg_size && recv_val!=-1 &&*/ strcmp(last_ch,end_dl)!=0)
				{		
					recv_val = recv (newsockfd,msg+i,1,0);
					last_ch[0]=last_ch[1];
					last_ch[1]=msg[i];
					last_ch[2]='\0';
					i++;
				}
				msg[strlen(msg)-2]='\0';
				printf("Recv :: %s  length = %d byte\n",msg,strlen(msg));	
				if(Is_a_cmd("USER",4,msg))
				{
					strcpy(user_name,msg+5);
					if(user_flag = is_user_there(user_name,usertext))
					{
						strcpy(send_msg,"+OK user found");	//<CRLF> char handling
						i=strlen(send_msg);
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);//send +OK user found
						printf("Repl :: %s",send_msg);
					}
					else
					{
						strcpy(send_msg,"-ERR user not found");	 //<CRLF> char handling
						i=strlen(send_msg);
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);//send -ERR user not found
						printf("Repl :: %s",send_msg);
					}
				}
				else if(Is_a_cmd("PASS",4,msg) && user_flag==1)
				{
					strcpy(user_pass,msg+5);
					if(is_pass_match(user_name,user_pass,usertext))
					{
						pass_flag=1;
						strcpy(send_msg,"+OK pass matched");	//<CRLF> char handling
						i=strlen(send_msg);
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);//send +OK user found
						printf("Repl :: %s",send_msg);
					}
					else
					{
						strcpy(send_msg,"-ERR password not match");//<CRLF> char handling
						i=strlen(send_msg);
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);//send -ERR pass not match
						printf("Repl :: %s",send_msg);
					}
				}
				else if(Is_a_cmd("STAT",4,msg) && pass_flag==1)
				{
					stat_val = stat_call(user_name,&no_mail,&no_oct);
					if(stat_val==1)
					{
						no_of_mail=in_to_str(no_mail,user_name);
						no_of_oct=in_to_str(no_oct,user_name);
						
						strcpy(send_msg,"+OK ");			// preparing msg
						strcat(send_msg,no_of_mail);
						strcat(send_msg," ");
						strcat(send_msg,no_of_oct);
						
						i=strlen(send_msg);				//<CRLF> char handling
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);	// send +OK msg
						printf("Repl :: %s",send_msg);
 						free(no_of_mail);
						free(no_of_oct);
					}
					else
					{
						printf("error in stat..\n");
					}
				}
			
				else if(Is_a_cmd("LIST",4,msg) && pass_flag==1 && strlen(msg)==4)
				{
					stat_val = stat_call(user_name,&no_mail,&no_oct);
					if(stat_val==1)
					{
						no_of_mail=in_to_str(no_mail,user_name);
						no_of_oct=in_to_str(no_oct,user_name);
						strcpy(send_msg,"+OK ");			// preparing msg
						strcat(send_msg,no_of_mail);
						strcat(send_msg," ");
						strcat(send_msg,no_of_oct);
						
						i=strlen(send_msg);				//<CRLF> char handling
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);	// send +OK msg
						printf("Repl :: %s",send_msg);
					}
					i=0;
					while(i < no_mail)
					{
						list_val = list_call(user_name,i+1,&no_oct);
						if(list_val==1)
						{
							str=in_to_str(i+1,user_name);		// preparing msg
							strcpy(send_msg,str);
							free(str);
							str=in_to_str(no_oct,user_name);
							strcat(send_msg," ");
							strcat(send_msg,str);
							free(str);
							
							j=strlen(send_msg);		//<CRLF> char handling
							send_msg[j]='\r';
							send_msg[j+1]='\n';
							send_msg[j+2]='\0';
							send(newsockfd,send_msg,strlen(send_msg),0);	// send msg
							printf("Repl :: %s",send_msg);	
						}
						else
						{
							printf("error in reading %d mail\n");
						}
						i++;
					}
					
					strcpy(send_msg,".");
					i=strlen(send_msg);				//<CRLF> char handling
					send_msg[i]='\r';
					send_msg[i+1]='\n';
					send_msg[i+2]='\0';
					send(newsockfd,send_msg,strlen(send_msg),0);
					printf("Repl :: %s",send_msg);		
				}
				else if(Is_a_cmd("LIST ",5,msg) && pass_flag==1)
				{
					list_val = list_call_no(user_name,str_to_int(msg+5,user_name),&no_oct);
					if(list_val==1)
					{
										// preparing msg
						strcpy(send_msg,msg+5);
						str=in_to_str(no_oct,user_name);
						strcat(send_msg," ");
						strcat(send_msg,str);
						free(str);
							
						j=strlen(send_msg);		//<CRLF> char handling
						send_msg[j]='\r';
						send_msg[j+1]='\n';
						send_msg[j+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);	// send msg
						printf("Repl :: %s",send_msg);	
					}
					else
					{
						printf("error in reading %d mail\n");
					}
				}
				else if(Is_a_cmd("RETR",4,msg) && pass_flag==1)
				{
					demand = str_to_int(msg+5,user_name);
					list_val = list_call(user_name,demand,&no_oct);	
					if(list_val==1)
					{
						str=in_to_str(no_oct,user_name);
						strcpy(send_msg,"+OK ");	// preparing msg
						strcat(send_msg,str);
						free(str);
						
						strcat(send_msg," ");
						strcat(send_msg,"(octets)");
												
						i=strlen(send_msg);		//<CRLF> char handling
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);// send msg	
						printf("Repl :: %s",send_msg);
						
						send_mail(user_name,demand,newsockfd);
					}
					else
					{
						printf("error in retr...\n");
					}
				}
			
				else if(Is_a_cmd("DELE",4,msg) && pass_flag==1)
				{
					demand = str_to_int(msg+5,user_name);
					if(del_call(demand,user_name) && demand!=0)
					{
						strcpy(send_msg,"+OK mail_no ");
						strcat(send_msg,msg+5);
						strcat(send_msg," ");
						strcat(send_msg,"deleted");
						i=strlen(send_msg);		//<CRLF> char handling
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);
						printf("Repl :: %s",send_msg);
					}
					else
					{	
						strcpy(send_msg,"-ERR mail delete");
						i=strlen(send_msg);		//<CRLF> char handling
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);
						printf("Repl :: %s",send_msg);
					
					}	
				}
				else if(Is_a_cmd("RSET",4,msg))
				{
					if(rest_call(user_name))
					{
						strcpy(send_msg,"+OK mailbox reset");
						i=strlen(send_msg);		//<CRLF> char handling
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);
						printf("Repl :: %s",send_msg);
					}
					else
					{
						strcpy(send_msg,"-ERR mailbox not set");
						i=strlen(send_msg);		//<CRLF> char handling
						send_msg[i]='\r';
						send_msg[i+1]='\n';
						send_msg[i+2]='\0';
						send(newsockfd,send_msg,strlen(send_msg),0);
						printf("Repl :: %s",send_msg);
					}
				
				}
				else if(Is_a_cmd("QUIT",4,msg))
				{
					if(quit_call(user_name))
					{
					strcpy(send_msg,"+OK ");
					strcat(send_msg,user_name);
					strcat(send_msg," ");
					strcat(send_msg,"POP3 server signing off");
					
					i=strlen(send_msg);		//<CRLF> char handling
					send_msg[i]='\r';
					send_msg[i+1]='\n';
					send_msg[i+2]='\0';
					send(newsockfd,send_msg,strlen(send_msg),0);
					printf("Repl :: %s",send_msg);		
					flag=0;	
					}	
				}
				else if(Is_a_cmd("NOOP",4,msg) && pass_flag==1)
				{
					send(newsockfd,"+OK reconnected\r\n",strlen("+OK reconnected\r\n"),0);
				}
				else
				{
					printf("wrong command is entered\n");
					strcpy(send_msg,"-ERR wrong command connection closed\r\n");
					send(newsockfd,send_msg,strlen(send_msg),0);
					printf("Repl :: %s",send_msg);	
					flag=0;
				}
			}
			
			close(newsockfd);
			exit(1);
		}
		close(newsockfd);
	}
	return 0;
}

int rest_call(char* user_name)
{
	FILE *fp;
	char path[path_len];
	int fd;
	
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/del_tmp.txt");
	
	fp=fopen(path,"w");
	if(fp==NULL)
	{
		return 0;
	}
	fd=fileno(fp);

	if(flock(fd,LOCK_EX))
	{
		return 0;
	}
	
	flock(fd,LOCK_UN);
	fclose(fp);
	return 1;


}
				
int Is_a_cmd(char *cmd,int size,char *msg)
{
	int i=0;
	int ret_val=1;
	if(size!=strlen(cmd))
	{
		printf("error in Is_a_cmd()\n");
	}
	else
	{
		if(strncasecmp(cmd,msg,size))
		{
			ret_val=0;
		}
		else
		{
			ret_val=1;
		}
	}
	return ret_val;
}

int stat_call(char *user_name,int *no_mail,int *no_oct)
{
	FILE *fp;
	char path[path_len];
	char buff[line_len];
	int no_of_mail=0;
	int no_of_oct=0;
	int fd;
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/mymailbox");
	fp=fopen(path,"r");
	fd=fileno(fp);
	
	if(fp==NULL)
	{
		printf("error in opening of %s file\n",path);
		return 0;
	}
	
	if(flock(fd,LOCK_SH)==-1)
	{
		printf("error in opening of %s file\n",path);
		return 0;
	}
	
	memset(buff,'\0',line_len);
	fgets(buff,line_len,fp);
	
	
	while(!feof(fp))
	{
		if(Is_a_cmd("From:",5,buff)||
		Is_a_cmd("To:",3,buff)||
		Is_a_cmd("Subject:",8,buff)||
		Is_a_cmd("Date:",5,buff)||
		Is_a_cmd("Message-ID:",11,buff))
		{
			fgets(buff,line_len,fp);
			
		}
		else
		{
			buff[strlen(buff)-1]='\0';
			if(!strcmp(buff,"."))
			{
				no_of_mail++;
			}
			else
			{
				no_of_oct = no_of_oct + strlen(buff);
			}
			fgets(buff,line_len,fp);
		}
	}
	
	flock(fd,LOCK_UN);
	fclose(fp);
	
	*no_mail=no_of_mail;
	*no_oct=no_of_oct;
	return 1;
}


char* in_to_str(int no_int,char *user_name)
{
	FILE *fp;
	char str[10],*str_int;
	char path[path_len];
	int fd;
	/*strcpy(path,mailbox_path);
	strcat(path,user_name);*/
	strcpy(path,"temp.txt");
	
	fp=fopen(path,"w");
	fd=fileno(fp);
	flock(fd,LOCK_EX);
	fprintf(fp,"%d",no_int);
	flock(fd,LOCK_UN);
	fclose(fp);
	
	fp=fopen(path,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	fscanf(fp,"%s",str);
	flock(fd,LOCK_UN);
	fclose(fp);
	
	str_int=(char*)malloc(strlen(str)*sizeof(char)+1);
	strcpy(str_int,str);
	return str_int;
}

int str_to_int(char *str_int,char *user_name)
{
	FILE *fp;
	int ret_val;
	char path[path_len];
	int fd;
	/*strcpy(path,mailbox_path);
	strcat(path,user_name);*/
	strcpy(path,"temp.txt");
	
	fp=fopen(path,"w");
	fd=fileno(fp);
	flock(fd,LOCK_EX);
	fprintf(fp,"%s",str_int);
	flock(fd,LOCK_UN);
	fclose(fp);
	
	fp=fopen(path,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	fscanf(fp,"%d",&ret_val);
	flock(fd,LOCK_UN);
	fclose(fp);
	return ret_val;
	
}


int list_call(char *user_name,int mail_no,int* mail_size)
{
	FILE *fp;
	char path[path_len];
	char buff[line_len];
	int i=1;
	int no_of_oct=0;
	int fd;
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/mymailbox");
	fp=fopen(path,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	if(fp==NULL)
	{
		printf("error in opening of mymailbox file\n");
		return 0;
	}
	fgets(buff,line_len,fp);
	while(!feof(fp))
	{
		if(Is_a_cmd("From:",5,buff)||
		   Is_a_cmd("To:",3,buff)||
		   Is_a_cmd("Subject:",8,buff)||
		   Is_a_cmd("Date:",5,buff)||
		   Is_a_cmd("Message-ID:",11,buff))
		{
			fgets(buff,line_len,fp);
		}
		else
		{
			buff[strlen(buff)-1]='\0';
			if(strcmp(buff,".")!=0)
			{
				if(i==mail_no)
					no_of_oct = no_of_oct+strlen(buff);
			}
			else
			{
				i++;
			}
			fgets(buff,line_len,fp);
		}
	}
	
	*mail_size = no_of_oct;
	flock(fd,LOCK_UN);
	fclose(fp);
	return 1;
}


int list_call_no(char *user_name,int mail_no,int* mail_size)
{
	FILE *fp;
	char path[path_len];
	char buff[line_len];
	int i=1;
	int no_of_oct=0;
	int fd;
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/mymailbox");
	fp=fopen(path,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	if(fp==NULL)
	{
		printf("error in opening of mymailbox file\n");
		return 0;
	}
	fgets(buff,line_len,fp);
	while(!feof(fp))
	{
		if(Is_a_cmd("From:",5,buff)||
		   Is_a_cmd("To:",3,buff)||
		   Is_a_cmd("Subject:",8,buff)||
		   Is_a_cmd("Date:",5,buff)||
		   Is_a_cmd("Message-ID:",11,buff))
		{
			fgets(buff,line_len,fp);
		}
		else
		{
			buff[strlen(buff)-1]='\0';
			if(strcmp(buff,".")!=0)
			{
				if(i<=mail_no)
					no_of_oct = no_of_oct+strlen(buff);
			}
			else
			{
				i++;
			}
			fgets(buff,line_len,fp);
		}
	}
	
	*mail_size = no_of_oct;
	flock(fd,LOCK_UN);
	fclose(fp);
	return 1;
}

int is_user_there(char *user_name,char *file)
{
	FILE *fp;
	char buff[line_len];
	int ret_val=0;
	int fd;
	fp=fopen(file,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	
	if(fp==NULL)
	{
		printf("error in opening of file\n");
		return 0;
	}

	while(!feof(fp))
	{
		fgets(buff,line_len,fp);
		if(Is_a_cmd(user_name,strlen(user_name),buff))
		{
			ret_val=1;
			break;
		}
	}
	flock(fd,LOCK_UN);
	fclose(fp);
	return ret_val;
}


int is_pass_match(char *user_name,char *user_pass,char *file)
{
	FILE *fp;
	char buff[line_len];
	int ret_val=0;
	int fd;
	fp=fopen(file,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	if(fp==NULL)
	{
		printf("error in opening of file\n");
		return 0;
	}
	while(!feof(fp))
	{
		fgets(buff,line_len,fp);
	if(Is_a_cmd(user_name,strlen(user_name),buff) && Is_a_cmd(user_pass,strlen(user_pass),buff+strlen(user_name)+1))
		{
			ret_val=1;
			break;
		}
	}
	flock(fd,LOCK_UN);
	fclose(fp);
	return ret_val;
}

void send_mail(char *user_name,int demand,int newsockfd)
{
	FILE *fp;
	char path[path_len];
	char buff[line_len];
	int i=1,j=0;
	int fd;
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/mymailbox");
	fp=fopen(path,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	if(fp==NULL)
	{
		printf("error in opening of mymailbox file\n");
	}
	
	if(feof(fp))
		send(newsockfd,".\r\n",strlen(".\r\n"),0);
		
	fgets(buff,line_len,fp);
	printf("\n\nSend to user :: mail no %d\n",demand);
	
	if(feof(fp))
		send(newsockfd,".\r\n",strlen(".\r\n"),0);	
	
	while(!feof(fp) && i <= demand)
	{
		buff[strlen(buff)-1]='\0';
		if(i == demand)
		{
			j=strlen(buff);		//<CRLF> char handling
			buff[j]='\r';
			buff[j+1]='\n';
			buff[j+2]='\0';
			send(newsockfd,buff,strlen(buff),0);
			printf("\t\t%s",buff);
		}
		
		if(strlen(buff)>=2)
		{
			buff[strlen(buff)-2]='\0';
		}
			
		if(strcmp(buff,".")==0)
		{
			i++;
			fgets(buff,line_len,fp);
		}
		else	
		{
			fgets(buff,line_len,fp);
		}
	}
	flock(fd,LOCK_UN);
	fclose(fp);
}


int del_call(int demand,char *user_name)
{
	FILE *fp;
	int fd;
	char path[path_len];
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/del_tmp.txt");
	
	fp=fopen(path,"a");
	fd=fileno(fp);
	flock(fd,LOCK_EX);
	if(fp==NULL)
	{
		printf("error in del_tmp.txt\n");
		return 0;
	}
	fprintf(fp,"%d ",demand);
	flock(fd,LOCK_UN);
	fclose(fp);
	return 1;
}

int quit_call(char *user_name)
{
	FILE *fp,*fp1;
	
	int demand[20],i=0,j=0;
	int total_del,flag=1;
	char path[path_len];
	char buff[line_len];
	int fd,fd1;
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/del_tmp.txt");
	fp=fopen(path,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	while(!feof(fp))
	{
		fscanf(fp,"%d",&demand[i++]);
	}
	total_del=i;
	i=1;
	flock(fd,LOCK_UN);
	fclose(fp);
						//for clear file
	
	fp=fopen(path,"w");
	fd=fileno(fp);
	flock(fd,LOCK_EX);
	if(fp==NULL)
	{
		printf("error in file del_tmp.txt\n");
		return 0;
	}
	flock(fd,LOCK_UN);
	fclose(fp);
	
	
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/mymailbox");
	fp=fopen(path,"r");
	fd=fileno(fp);
	flock(fd,LOCK_SH);
	if(fp == NULL)
	{
		printf("error in file path\n");
		return 0;
	}
	
	/*strcpy(path,mailbox_path);
	strcat(path,user_name);*/
	strcpy(path,"temp.txt");
	fp1=fopen(path,"w");
	fd1=fileno(fp1);
	flock(fd1,LOCK_UN);
	if(fp1==NULL)
	{
		printf("error in file temp.txt\n");
		return 0;
	}
	
	while(!feof(fp))
	{
		j=0;
		flag=1;	
		fgets(buff,line_len,fp);
		while(j < total_del)
		{
			if(demand[j]==i)
			{
				flag=0;
				break;	
			}
			j++;
		}
		j=0;
	
		if(flag)
		{
			fputs(buff,fp1);
		}
			
		if(strcmp(buff,".\n") == 0)
		{
			i=i+1;
		}
	}
	flock(fd,LOCK_UN);
	fclose(fp);
	flock(fd1,LOCK_UN);
	fclose(fp1);
	
	strcpy(path,mailbox_path);
	strcat(path,user_name);
	strcat(path,"/mymailbox");
	fp=fopen(path,"w");
	fd=fileno(fp);
	flock(fd,LOCK_EX);
	if(fp==NULL)
	{
		printf("error in file open 1\n");
		return 0;
	}
	
	
	/*strcpy(path,mailbox_path);
	strcat(path,user_name);*/
	strcpy(path,"temp.txt");
	fp1=fopen(path,"r");
	fd1=fileno(fp1);
	flock(fd1,LOCK_SH);
	if(fp1==NULL)
	{
		printf("error in file open 2\n");
		return 0;
	}
	
	while(!feof(fp1))
	{
		fgets(buff,line_len,fp1);
		fputs(buff,fp);
	}
	flock(fd,LOCK_UN);
	fclose(fp);
	flock(fd1,LOCK_UN);
	fclose(fp1);
	return 1;	
}



