/*pop cli prog */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<ctype.h>

/* The following three files must be included for network programming */
#include<sys/socket.h>
#include<netinet/in.h>
#include<arpa/inet.h>

/*For shared memory and semaphore*/
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/shm.h> 
#include <sys/sem.h>

/* For signal handling */
#include <unistd.h>
#include <errno.h>
#include <signal.h>

/*

ISSUES PENDING crlf /r/n. RECV BYTE BY BYTE

*/


//#define server_ip "10.14.1.109"
#define server_port 62105
#define USER 5
#define msg_size 100

/* functions definitions */

int authentication(int, char*);
int options(int sockfd);
void sendmsg1(int ,char*);
void sendmsg2(int ,char *);
void sendmsg3(int ,char *);
void sendmsglist(int ,char *);
/*------------- BEGINNING OF MAIN -----*/

int main(int argc, char *server_ip[])//TAKING IP ADDR ON COMMAND LINE
{
	int sockfd,i=0;
	char serv_msg[msg_size];
	struct sockaddr_in serv_addr;
	socklen_t servlen;
	
	if( argc == 2 )
	{
		printf("The argument supplied is %s\n", server_ip[1]);
	}
	else if( argc > 2 )
	{
		printf("Too many arguments supplied.\n");
		exit(0);
	}
	else
	{
		printf("One argument expected.\n");
		exit(0);
	}

//---------SOCKET FN CALL
	
	if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) 
	{
		perror("Cannot create socket\n");
		exit(0);
	}	
	
	serv_addr.sin_family		= AF_INET;
	serv_addr.sin_addr.s_addr	= inet_addr(server_ip[1]);
	serv_addr.sin_port		= htons(server_port);

//-----BIND CALL------------

	if ((connect(sockfd, (struct sockaddr *) &serv_addr,sizeof(serv_addr))) < 0) 
	{
		perror("Unable to connect to server\n");
		exit(0);
	}	


		for(i=0;i<30;i++)
		{
			if(recv(sockfd,serv_msg+i,1,0)!=-1)
			{
				if(i>0 && serv_msg[i]=='\n' && serv_msg[i-1]=='\r')
				{
					serv_msg[i-1]='\0';
					break;
				}
			}
			else
			printf("Error in recv");
		}

	//recv (sockfd,serv_msg,msg_size,0);
	printf("FRom server %s\n",serv_msg);//+OK from server
	if(serv_msg[0]=='+')
	{
		authentication(sockfd,serv_msg);
	}
	else printf("error in connection est\n ");
	return 0;
}

//---------------------authorizaation STATE--------------------

int authentication(int sockfd,char* serv_msg)
	{
		char userid[10], password[10],username[30],pwd[30],s_username[30],s_pwd[100],last_ch[5],end_dl[5],spwd[30];
		int m=0,i=0,p,recv_val,flag;
		flag=0;
		end_dl[0]='\r';
		end_dl[1]='\n';
		end_dl[2]='\0';

		label1:			
		printf("enter userid\n");
		scanf("%s", userid);
		memset(username,'\0',30);	
		sprintf(username,"USER %s\r\n",userid);
		if(send(sockfd,username,strlen(username),0)<0)//username sent to the client
		{
			perror("sending username failed");
			exit(1);		
		}
		//printf("sending username %s\n", username);
		memset(s_username,'\0',30);		//clearing buffer bef receipt
		for(i=0;i<30;i++)
		{
			if(recv(sockfd,s_username+i,1,0)!=-1)//+ok for username
			{	
				//printf("from raj	%c\n", s_username[i]);
				if(i>0 && s_username[i]=='\n' && s_username[i-1]=='\r')
				{
					s_username[i-1]='\0';
					break;
				}
			}
			else
			printf("Error in recv");
		}
		//recv(sockfd,s_username,30,0);	
		//printf("recd message from server		%s \n",s_username );//for +ok username recipt
		for(i=0;i<msg_size;i++)
		{
			if(s_username[i]=='+')//for corret username now ask for pwd 
			{
				printf("found +\n 	");			
				flag= 1;
				break;
			}
		}
			if (flag==1)
			{	
				label:		
				printf("enter password\n");
				scanf("%s", password);
				sprintf(pwd,"PASS %s\r\n",password);
				//printf ("sentding	%s\n	",pwd);
				if(send(sockfd,pwd,strlen(pwd),0)<0)//sending pwd
				{
					perror("sending password failed");
					exit(1);		
				}
					
				//-------------for rx byte by byte----------------
				else 
				{
					for(i=0;i<30;i++)
					{
						if(recv(sockfd,s_pwd+i,1,0)!=-1 )//recv confirmation for pwd
						{	
							//printf("from server reply to pwd	%c \n",s_pwd[i]);
							if(i>0 && s_pwd[i]=='\n' && s_pwd[i-1]=='\r')
							{
								s_pwd[i-1]='\0';
								break;
							}
						}
						else
						printf("Error in recv");
					}
								//recv(sockfd,s_pwd,30,0);
				}
				for(i=0,p=0;i<100;i++)			
				{			
					if(s_pwd[i]!='\0')			
						{
						spwd[p]=s_pwd[i];
						p++;}
	//				printf("recv from server reply to server is%s\n",s_pwd[i]);
				}
			}
		else 
		while(m!=3)
			{
				printf("wrong id enter again\n");			
				m++;
				goto label1;
			}		
		if (m==3)
		{
			printf("ur chances over bye bye\n");
			exit (1);
		}
	
		for(i=0;i<100;i++)
		{	
			//printf("inside lop	%c\n", spwd[i]);		
			if(spwd[i]=='+')
			{	
				//printf("again loo[p %c",spwd[i]);
				//printf("%s\n",spwd);		
				memset(spwd,'\0',30);			
				options(sockfd);
				return 0;	
			}	
			else printf("wrong password enter again\n	");
				goto label;
		}	
			
		
			return 0;
			
		}

//--------------TRANSACTION STATE--------------------

int options(int sockfd)
{
	int choice;
	char msg[30],msg1[30];
	while(1)
	{
		printf("enter choices		1.finding the num of msgs & size\n			2.list\n			3.retrieve\n			4.rset\n			5.Noop\n			6.delete\n			7.quit\n	");
		scanf("%d", &choice);
		switch(choice)
		{
			case 1:	sprintf(msg,"STAT\r\n");
					sendmsg2(sockfd,msg);
					break;
			case 2: sprintf(msg1,"LIST\r\n");
					printf("here	%s\n",msg1);
					sendmsglist(sockfd,msg1);
					break;
			case 3: sprintf(msg,"RETR");
					sendmsg3(sockfd,msg);
					break;
			case 4: sprintf(msg,"RSET\r\n");
					sendmsg2(sockfd,msg);
					break;
			case 5: sprintf(msg,"NOOP\r\n");
					sendmsg2(sockfd,msg);
					break;
			case 6: sprintf(msg,"DELE");
					sendmsg1(sockfd,msg);
					break;
			case 7: sprintf(msg,"QUIT\r\n");
					sendmsg2(sockfd,msg);				
					close(sockfd);
					exit(1);
		}
	}
	return 0;
}


void sendmsg2(int sockfd,char* msg)// FOR STAT, QUIT,NOOP
{
	char r_msg[3000],check[30];
	int i =0;
	send(sockfd,msg,strlen(msg),0);	///CHAR POINTER ???
	printf("sending to server	%s",msg);	
	memset(r_msg,'\0',3000);
	memset(msg,'\0',30);	
	//recv(sockfd,r_msg,30,0);

	for(i=0;i<3000;i++)
			{
				if(recv(sockfd,r_msg+i,1,0)!=-1)
				{
					printf("%c",r_msg[i]);	
					if(i>0 && r_msg[i]=='\n' && r_msg[i-1]=='\r')
					{
						r_msg[i-1]='\0';
						break;
					}
				}
				else
				{
					printf("Error in recv");
					//display_receive_error(byte_recv);
				}
			}
	if(r_msg[0]=='-')
	{
		perror("error in receive message	\n");
		exit(1);
	}
	else
	printf("recd from server in reply 	%s\n",r_msg);
	memset(r_msg,'\0',30);
	memset(msg,'\0',30);
}		

//----------- FOR LISTING/ DELETING A PARTICULAR MESSAGE------------

void sendmsg1(int sockfd,char msg[])//RSET DELE
{
	char num[2],r_msg[3000],rx[30],msg3[30];
	int i=0;
	printf("enter tessage num	");
	fflush(stdin);
	scanf("%s",&num);

	strcpy(msg3," ");
	strcat(msg3,num)	;
	strcat(msg3,"\r\n")	;	
	strcat(msg,msg3)	;
	send(sockfd,msg,strlen(msg),0);//SENDING TO SEREVER WITH OPTINOS
	printf("sending the option for deleetin %s", msg);
	memset(r_msg,'\0',3000);
	//recv(sockfd, r_msg,30,0);
	for(i=0;i<3000;i++)
			{
				if(recv(sockfd,r_msg+i,1,0)!=-1)
				{				
					printf("%c",r_msg[i]);	
					if(i>0 && r_msg[i]=='\n' && r_msg[i-1]=='\r')
					{
						r_msg[i-1]='\0';
						break;
					}
				}
				else
				printf("Error in recv");
			}
	if(r_msg[0]=='-')
	{
		perror("error in receive message	\n");
		exit(1);
	}
	else printf("after deletion%s\n",r_msg);
}

//----------- FOR RETRIEVING A PAERTICULAR MESSAGE------------

void sendmsg3(int sockfd,char msg[])
{
	char num,r_msg[20000],rx[30],msg3[30],end_dl[6],last[6];
	int i=0;
	strcpy(end_dl,"\r\n.\r\n");
	strcpy(end_dl,"abcde");
	printf("enter the message numto be retrieved\n");
	scanf("%s",&num);
	sprintf(msg3," %c\r\n",num);
//	printf("")
	strcat(msg,msg3);
	send(sockfd,msg,strlen(msg),0);//SENDING TO SEREVER WITH OPTINOS
	printf("sending the option for retrieving	%s\n", msg);

	//recv(sockfd, r_msg,30,0);
	while(strcmp(end_dl,last)!=0)
	{
		memset(r_msg,'\0',1000);
		fflush(stdout);
		//printf("compared value	%d",strcmp(end_dl,last));
		for(i=0;i<20000;i++)
		{	
			/*if(recv(sockfd,r_msg+i,1,0)!=-1)
			{
				last[0]=last[1];
				last[1]=last[2];
				last[2]=last[3];
				last[3]=last[4];
				last[4]=r_msg[i];
				last[5]='\0';				
				if(i>0 && r_msg[i]=='\n' && r_msg[i-1]=='\r')
				{
					r_msg[i-1]='\0';
					break;
				}
				
			}*/
			if(recv(sockfd,r_msg+i,1,0)!=-1)

			{//printf("%c",r_msg[i]);
				if(i>0 && r_msg[i]=='\n' && r_msg[i-1]=='\r' && r_msg[i-2]=='.' && r_msg[i-3]=='\n' && r_msg[i-4]=='\r')
				{
					r_msg[i-4]='\0';
					break;
				}
			}	
			else
				printf("Error in recv");
		}
		//printf("last value	\n\na%s",last);
		if(r_msg[0]=='-')
		{
			perror("error in receive message	\n");
			exit(1);
		}
		else 
		{
			printf("%s\n",r_msg);
			break;
		}
		
	}
printf("out of loop\n");
}


void sendmsglist(int sockfd,char msg[])
{
	char r_msg[3000],check[30];
	int i =0;
	send(sockfd,msg,strlen(msg),0);	///CHAR POINTER ???
	printf("sending to server	%s",msg);	
	memset(r_msg,'\0',3000);
	for(i=0;i<3000;i++)
	{
		if(recv(sockfd,r_msg+i,1,0)!=-1)
		{			//	printf("%c",r_msg[i]);	
			//printf("%c",r_msg[i]);	
			if(i>0 && r_msg[i]=='\n' && r_msg[i-1]=='\r' && r_msg[i-2]=='.' && r_msg[i-3]=='\n' && r_msg[i-4]=='\r')
			{
				r_msg[i-4]='\0';
				break;
			}
		}
		else
			printf("Error in recv");
		//	memset
	}
	if(r_msg[0]=='-')
	{
		perror("error in receive message	\n");
		exit(1);
	}
	else printf("got it%s\n",r_msg);
}

















/*
receivemsg()
{
for(i=0;i<30;i++)
		{
			if(recv(sockfd,s_username+i,1,0)!=-1)
			{
				if(i>0 && s_username[i]=='\n' && s_username[i-1]=='\r')
				{
					s_username[i-1]='\0';
					break;
				}
			}
			else
			{
				printf("Error in recv");
				//display_receive_error(byte_recv);
			}
		}

}
*/

