//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 7:: SMTP Client

///////////////#includes ////////////////

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>
#include<assert.h>
#include<ctype.h>
#include<time.h>

//////////////////////////////////////////


//////////////////#defines ///////////////

//#define IP "127.0.0.1"
//#define IP "10.14.1.102"
//#define IP "10.14.88.156"
//#define PORT 60003
//#define SIZE 77

//////////////////////////////////////////


////////Structure definitions /////////



//////////////////////////////////////////


////// function prototypes ///////

void fflushstdin( void );
void clrscr(void);
int getMsg(char* src,char* dst);
int properMailFormat(char *mailID);
int is_valid_ip(const char *ip_str);
int is_valid_port(char *str);
int is_valid_size(char *str);
ssize_t recvBbB(int sockfd, void *buf, size_t len, int flags);
int isNum(char *str);

///////////////////////////////////


///////global variables///////

char IP[16];
int PORT = 60000,SIZE = 77;

//////////////////////////////



//////////////////////////
///// MAIN FUNCTION //////
//////////////////////////

/*
This is a SMTP mail client -->Caller should provide IP/domainName and port number
call this function to send mail
On successfull mail delivery this function will return 1
Otherwise it will exit returning a 0
*/
int main(int argc,char **argv)
{
	int conSock;
	struct sockaddr_in sAddr;
	char buf[SIZE];
	FILE *body;
	
	int d,i=1;
	char s1[SIZE],s2[SIZE],s3[SIZE],s4[SIZE];
	
	char *param;
	
	strcpy(IP,"127.0.0.1");

	if (argc == 1)
	{
				printf("USAGE: <coammand> [-p <portNo>] [-i <ipAddress>][-s <size>][-h]\nDEFAULTS: ip<127.0.0.1> port<60000> size<77> \nHELP --	OPTIONS\n");
				printf("\t-i\t:: IP address\n");
				printf("\t-p\t:: Port No\n");
				printf("\t-s\t:: Size of the Mgs per line\n");
				printf("\t-d\t:: Take default Values and Run\n");
				printf("\t-h\t:: Help\n");
				return 0;
	}
label:
	if(i<argc)
	{
		param=strtok(argv[i],"-");
		switch(param[0])
		{
			case 'd':
				i++;
				break;
			case 'i':
				if(i+1<argc && is_valid_ip(argv[i+1])){
				strcpy(IP,argv[i+1]);
//				printf("%s\n",IP);
				i=i+2;
				}
				else
				{
					printf("Provide Valid IP Address\n",IP);
					return 0;
				}
				break;
			case 'p':
				if(i+1<argc && is_valid_port(argv[i+1])){
				PORT = atoi(argv[i+1]);
//				printf("%d\n",PORT);
				i+=2;
				}
				else
				{
					printf("Provide Valid Port Number\n",IP);
					return 0;
				}
				break;
			case 's':
				if(i+1<argc && is_valid_size(argv[i+1])){
				SIZE = atoi(argv[i+1]);
//				printf("%d\n",SIZE);
				i+=2;
				}
				else
				{
					printf("Provide Valid Size\n",IP);
					return 0;
				}
				break;
			case 'h':
				printf("USAGE: <coammand> [-p <portNo>] [-i <ipAddress>][-s <size>][-h]\nDEFAULTS: ip<127.0.0.1> port<60000> size<77> \nHELP --	OPTIONS\n");
				printf("\t-i\t:: IP address\n");
				printf("\t-p\t:: Port No\n");
				printf("\t-s\t:: Size of the Mgs per line\n");
				printf("\t-d\t:: Take default Values and Run\n");
				printf("\t-h\t:: Help\n");
				return 0;
				break;
			default:
				printf("Unknwn Option : %s\n",argv[i]);
				printf("USAGE: <coammand> [-p <portNo>] [-i <ipAddress>][-s <size>][-h]\nDEFAULTS: ip<127.0.0.1> port<60000> size<77> \nHELP --	OPTIONS\n");
				printf("\t-i\t:: IP address\n");
				printf("\t-p\t:: Port No\n");
				printf("\t-s\t:: Size of the Mgs per line\n");
				printf("\t-d\t:: Take default Values and Run\n");
				printf("\t-h\t:: Help\n");
				return 0;
		}
	}
if(i<argc)
	goto label;	
	
	if(getMsg(s3,s4))
	{
	printf("%s--->%s\n\n",s3,s4);
		
		if((conSock = socket(AF_INET,SOCK_STREAM,0)) < 0)
		{
			perror("SocketError");
			return(0);	
		}printf("socket created\n");
		
		sAddr.sin_family = AF_INET;
		sAddr.sin_addr.s_addr = inet_addr(IP);
		sAddr.sin_port = htons(PORT);
		
		if(connect(conSock,(struct sockaddr*)&sAddr,sizeof(sAddr)) < 0)
		{
			perror("ConnectError");
			return(0);
		}printf("Connected\n");
		
		buf[recv(conSock,buf,SIZE,0)]= '\0';
		printf("\nRcv:: %s\n",buf);
		
		sscanf(buf,"%d %s",&d,s1);
		if(d != 220)
		{
			printf("\n-->ERROR!!\ncommand-responses-ERROR: %s\n",buf);
			close(conSock);
			return(0);
		}
		sprintf(buf,"HELO <%s>\r\n",strchr(s3,'@')+1);

		send(conSock,buf,strlen(buf),0);
		printf("sent:: %s",buf);
		
		buf[recv(conSock,buf,SIZE,0)]= '\0';
		printf("\nRcv:: %s\n",buf);
		
		sscanf(buf,"%d %*s",&d);		
		if(d != 250)
		{
			printf("\n-->ERROR!!\ncommand-responses-ERROR: %s\n",buf);
			close(conSock);
			return(0);
		}
		sprintf(buf,"MAIL FROM:<%s>\r\n",s3);
		
		send(conSock,buf,strlen(buf),0);
		printf("sent:: %s",buf);
		
		buf[recv(conSock,buf,SIZE,0)]= '\0';
		printf("\nRcv:: %s\n",buf);
		
		sscanf(buf,"%d %s %s",&d,s1,s2);
		
		if(d == 550)
		{
			printf("\n-->USER NOT FOUND: %s\n",buf);
			close(conSock);
			return(0);
		}
		if(d != 250)// && !strcasecmp(s3,s1))		//<----------check here
		{
			printf("\n-->ERROR!!\ncommand-responses-ERROR: %s\n",buf);
			close(conSock);
			return(0);
		}
		
		sprintf(buf,"RCPT TO:<%s>\r\n",s4);
		
		send(conSock,buf,strlen(buf),0);
		printf("sent:: %s",buf);
		
		buf[recv(conSock,buf,SIZE,0)]= '\0';
		printf("\nRcv:: %s\n",buf);
		
		sscanf(buf,"%d %s %s",&d,s1,s2);
		
		if(d != 250)
		{
			printf("\n-->ERROR!!\ncommand-responses-ERROR: %s\n",buf);
			close(conSock);
			return(0);
		}
		sprintf(buf,"DATA\r\n");
		
		send(conSock,buf,strlen(buf),0);
		printf("sent:: %s",buf);
			
		buf[recv(conSock,buf,SIZE,0)]= '\0';
		printf("\nRcv:: %s\n",buf);
		
		sscanf(buf,"%d %s",&d,s1);
		if(d != 354)
		{
			printf("\n-->ERROR!!\ncommand-responses-ERROR: %s\n",buf);
			close(conSock);
			return(0);
		}
	
////////////////// SENDING OF MESSAGE BODY //////////////////////////////////////////
		body=fopen("_bodyTmp.blah_","r");	
		while(!feof(body))
		{
			fgets(buf,SIZE+3,body);
			printf("sent:: %s",buf);
			send(conSock,buf,strlen(buf),0);//sleep(1);
			if(!strcmp(buf,".\r\n"))
				break;
		}
		fclose(body);
	//	remove("_bodyTmp.blah_");
//////////////////////////////////////////////////////////////////////////////////////
		
		buf[recv(conSock,buf,SIZE,0)]= '\0';
		printf("\nRcv:: %s\n",buf);
		
		sscanf(buf,"%d %s",&d,s1);
		if(d != 250)
		{
			printf("\n-->ERROR!!\ncommand-responses-ERROR: %s\n",buf);
			close(conSock);
			return(0);
		}
		sprintf(buf,"QUIT\r\n");
		
		send(conSock,buf,strlen(buf),0);
		printf("sent:: %s",buf);
	
		buf[recv(conSock,buf,SIZE,0)]= '\0';
			printf("\nRcv:: %s\n",buf);
		
		sscanf(buf,"%d %s",&d,s1);
		if(d != 221)
		{
			printf("\n-->ERROR!!\ncommand-responses-ERROR: %s\n",buf);
			close(conSock);
			return(0);
		}
		
		printf("\nMessage Sent Successfully!!\n\n");
		printf("\npress any key to continue...");
		close(conSock);
	}
	else
		printf("\nError!!\nMessege sending Failed.");

	//	system("stty raw");
//		getchar();
	//	system("stty cooked");
//clrscr();
return 1;
}




/*
this function takes input on behalf of the main from the user 
and saves the messese to send in a file named "_bodyTmp.blah_"
This function takes two parameter "src" and "dst"
in which it will return the source and destination address respectively

on success it will return 1 otherwise 0
*/
int getMsg(char* src,char* dst)
{
	FILE *fp=fopen("_bodyTmp.blah_","w");
	char buf[SIZE];
	int chck;
	
	if(fp)
	{
		printf("\n\nHere Type in your messege...\n\nMAX char per line: %d\nAddress format: X@Y\n\n",SIZE);	
		
		printf("From: ");
		
		fgets (src, SIZE, stdin);
		if(!properMailFormat(src))
		{
			printf("\n-->Error Source Mail Format:%s", src);
			fclose(fp);
			return 0;
		}
		
		fprintf(fp,"FROM:<%s",src);
		src[strlen(src)-1]=0;
		fseek(fp,-1,SEEK_CUR);
		fputs(">\r\n",fp);
		
		printf("TO: ");
		
		fgets (dst, SIZE, stdin);
		if(!properMailFormat(dst))
		{
			printf("\n-->Error Destination Mail Format:%s", dst);
			fclose(fp);
			return 0;
		}
				
		fprintf(fp,"TO:<%s",dst);
		dst[strlen(dst)-1]=0;
		fseek(fp,-1,SEEK_CUR);
		fputs(">\r\n",fp);
	
		printf("Subject: ");
	
		fgets (buf, SIZE, stdin);
		fprintf(fp,"SUBJECT: %s",buf);
		fseek(fp,-1,SEEK_CUR);
		fputs("\r\n",fp);
		
		printf("\nStart Typing Messege..<END it with \"[ENTER].[ENTER]\">\n\n");
		do
		{
			fgets (buf, SIZE, stdin);
			fputs(buf,fp);
			fseek(fp,-1,SEEK_CUR);
			fputs("\r\n",fp);
			chck=strcmp(buf,".\n");
		}while(chck!=0);

	}
	else
	{
		printf("\n-->Error Opening temporary FILE");
	return 0;
	}
	fclose(fp);
	return 1;
}



/*
this function checks validity of mail address format 

On success it will return 1 otherwise 0
*/
int properMailFormat(char *mailID)
{
	char *indexOFat;
	indexOFat = strchr(mailID,'@');

	if(indexOFat)
	{
		if(strchr(indexOFat+1,'@'))
		{
			printf("\n-->Multiple '@'");
			return 0;
		}
	
		if(!strcmp(indexOFat+1,""))
		{
			printf("\n-->Domian name cannot be NULL");
			return 0;
		}
	
		if(mailID == indexOFat)
		{
			printf("\n-->User name cannot be NULL");
			return 0;
		}
	}
	else
	{
			printf("\n-->'@' not found");
			return 0;
	}
return 1;
}


/*
this function checks for vlaidity format of IP address
on success returns 1 else 0
*/
int is_valid_ip(const char *ip_str)
{
	unsigned int n1,n2,n3,n4;

	if(sscanf(ip_str,"%u.%u.%u.%u", &n1, &n2, &n3, &n4) != 4) return 0;

	if((n1 != 0) && (n1 <= 255) && (n2 <= 255) && (n3 <= 255) && (n4 <= 255)) {
		char buf[64];
		sprintf(buf,"%u.%u.%u.%u",n1,n2,n3,n4);
		if(strcmp(buf,ip_str)) return 0;
		return 1;
	}
	return 0;
}


int isNum(char *str)
{
	int len = strlen(str);
	int i;
	for(i=0;i<len;i++)
	{
		if(!isdigit(str[i]))
		return 0;
	}
	return 1;
}



int is_valid_port(char *str)
{
	int no;
	if (isNum(str))
	{	
		no = atoi(str);
		if(no>5000 && no <64000)
		return 1;
		else return 0;
	}
	return 0;
}



int is_valid_size(char *str)
{
	if (isNum(str))
	{	
		if(atoi(str)<=77)
		return 1;
		else return 0;
	}
	return 0;
}



/*
This function receives byte by byte
*/
ssize_t recvBbB(int sockfd, void *buf, size_t len, int flags)
{
	int i;
	char* cBuf=(char*)buf;
	for(i=0;i<len;i++)
	{
		recv(sockfd,&cBuf[i],1,flags);
		if(cBuf[i] == '\n' && cBuf[i-1] == '\r')
		break;
	}
	return i;
}



/*
my clrscr()
*/
void clrscr(void)
{
		char str[] = " [H [2J";
		str[3] = str[0] = 27;
		write(1, str, 7);
}



/*
my fflush(stdin)
*/
void fflushstdin( void )
{
    int c;
    while( (c = fgetc( stdin )) != EOF && c != '\n' ); //pushes the pointer to EOF
}
