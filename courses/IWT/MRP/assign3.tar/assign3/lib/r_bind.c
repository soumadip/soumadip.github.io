//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>

#include"rsock.h"

/*
		binds the socket with some address-port using the bind call.
*/
int r_bind(int sockfd, const struct sockaddr *addr,socklen_t addrlen)
{
	int ret;
	if((ret=bind(sockfd,addr,addrlen))<0)
	{
		fprintf(stderr,"r_bind : cannot bind ");
		return -1;
	}
	return ret;
}

