#ifndef IP
#define IP "10.14.87.244"
#endif
#ifndef PORT
#define PORT 60112
#endif
#define SOCK_MRP 100
#define SIZE 255
#define ETX 3
#define R_TYPE 1
#define U_TYPE 2

#define P(s) semop(s, &pop, 1)  /* pop is the structure we pass for doing the P(s) operation */
#define V(s) semop(s, &vop, 1)  /* vop is the structure we pass for doing the V(s) operation */

////////Structure definitions /////////

typedef struct unackd
{
	char packet[SIZE];
	struct timeval timestamp;
	char addr[15];
	int portno;
	struct unackd *next;
}unackd;


typedef struct recvd
{
	char packet[SIZE];
	char addr[15];
	int portno;
	struct recvd *next;
}recvd;

//////////////////////////////////////////


///////global variables///////

unackd *unackdBuff;
recvd *recvdBuff;

int sockfd;
int unackSem, recvSem ;
struct sembuf pop,vop ;
pthread_t pth[2];
pthread_t R,S;
int ackCounter=0;

//////////////////////////////



////// function prototypes ///////

/*
my fflush(stdin)
*/
void fflushstdin();

/*
		The thread R/receive_routine behaves in the following manner. When it receives a message, if 
	it is a data message, it stores it in the received-message table, and sends an ACK message to the
	sender. If it is an ACK message in response to a previously sent message, it updates the
	unacknowledged-message table to take out the message for which the acknowledgement
	has arrived.

*/
void* send_routine(void* arg);

/*
		The thread S/send_routine behaves in the following manner. It sleeps for some time (T), and wakes up
	periodically. On waking up, it scans the unacknowledged-message table to see if any of
	the messages timeout period (set to 2T ) is over (from the difference between the time in
	the table entry for a message and the current time). If yes, it retransmits that message and
	resets the time in that entry of the table to the new sending time. If not, no action is taken.
	This is repeated for all messages in the table every time S wakes up.
*/
void* receive_routine(void* arg);

/*
		This function opens an UDP socket with the socket call. It also creates the
	2 threads R and S, and allocates initial space for the tables. The parameters to these
	are the same as the normal socket( ) call, except that it will take only SOCK_MRP as
	the socket type.
*/
int r_socket(int domain, int type, int protocol);

/*
		binds the socket with some address-port using the bind call.
*/
int r_bind(int sockfd, const struct sockaddr *addr,socklen_t addrlen);

/*
		sends the message immediately by sendto. It also adds a message sequence
	no. at the beginning of the message and stores the message along with its sequence
	no. and destination address-port in the unacknowledged-message table before
	sending the message. With each entry, there is also a time field that is filled up
	nitially with the time of first sending the message.

*/
ssize_t r_sendto(int sockfd, const void *buf, size_t len, int flags,const struct sockaddr_in *dest_addr, socklen_t addrlen);

/*
		looks up the received-message table to see if any message is already
	received in the underlying UDP socket or not. If yes, it returns the first message and
	deletes that message from the table. If not, it blocks the call. To block the r_recvfrom
	call, you can use sleep call to wait for some time and then see again if a message is
	received. r_recvfrom, similar to recvfrom, is a blocking call by default and returns to
	the user only when a message is available.

*/
ssize_t r_recvfrom(int sockfd, void *buf, size_t len, int flags,struct sockaddr_in *src_addr, socklen_t *addrlen);

/*
		closes the socket; kills all threads and frees all memory associated with the
	socket. If any data is there in the received-message table, it is discarded.

*/
int r_close(int fd);

/*
		where p is a probability between 0 and 1. This function first generates a random number
	between 0 and 999. If the generated number is < p, then the function returns 1, else it
	returns 0.


*/
int dropMessage();

/*
	finds differences between two timeval stucture's time
*/
long timevaldiff(struct timeval *starttime, struct timeval *finishtime);

/*
	destroyes buffers depending on their type specified by U_TYPE or R_TYPE
*/
int destroy(void* ptr, int type);

///////////////////////////////////
