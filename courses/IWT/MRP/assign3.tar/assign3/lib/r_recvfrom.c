//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>

#include"rsock.h"

/*
		looks up the received-message table to see if any message is already
	received in the underlying UDP socket or not. If yes, it returns the first message and
	deletes that message from the table. If not, it blocks the call. To block the r_recvfrom
	call, you can use sleep call to wait for some time and then see again if a message is
	received. r_recvfrom, similar to recvfrom, is a blocking call by default and returns to
	the user only when a message is available.

*/
ssize_t r_recvfrom(int sockfd, void *buf, size_t len, int flags,struct sockaddr_in *src_addr, socklen_t *addrlen)
{
	int counter=0,flag=0;
	recvd *ptr;
	char* cBuf=buf;
	while(strlen(cBuf)<len)
	{
	usleep(150000);
	P(recvSem);
		ptr=recvdBuff;
		while(ptr!=NULL)
		{
			if(!strcmp(ptr->packet,""))
			{
				flag=1;
				free(ptr);
				recvdBuff=NULL;
				break;
			}
			strcat(cBuf,ptr->packet);
			counter++;
			recvdBuff=recvdBuff->next;
			free(ptr);
			ptr=recvdBuff;
		}
	V(recvSem);
	if(flag) break;
	}
	return counter;
}

