//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>

#include"rsock.h"

/*
		closes the socket; kills all threads and frees all memory associated with the
	socket. If any data is there in the received-message table, it is discarded.

*/
int r_close(int fd)
{
	key_t key1,key2;
	key1=ftok("/tmp/",8);
	key2=ftok("/tmp/",7);
	semctl(key1,0,IPC_RMID);
	semctl(key2,0,IPC_RMID);
	pthread_kill(pth[0],SIGKILL);
	pthread_kill(pth[1],SIGKILL);
	destroy(unackdBuff,U_TYPE);
	destroy(recvdBuff,R_TYPE);
	return close(fd);
}



int destroy(void* ptr, int type)
{
	void *temp;
	switch (type)
	{
		case U_TYPE :
			while(ptr!=NULL)
			{
				temp=((unackd*)ptr)->next;
				free((unackd*)ptr);
				ptr=temp;
			}
			return 1;
		case R_TYPE :
			while(ptr!=NULL)
			{
				temp=((recvd*)ptr)->next;
				free((recvd*)ptr);
				ptr=temp;
			}
			return 1;
		default:
			fprintf(stderr,"wrong type");
			return -1;

	}
}
