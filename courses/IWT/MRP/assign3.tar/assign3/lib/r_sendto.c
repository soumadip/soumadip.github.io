//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>

#include"rsock.h"

/*
		sends the message immediately by sendto. It also adds a message sequence
	no. at the beginning of the message and stores the message along with its sequence
	no. and destination address-port in the unacknowledged-message table before
	sending the message. With each entry, there is also a time field that is filled up
	nitially with the time of first sending the message.

*/
ssize_t r_sendto(int sockfd, const void *buf, size_t len, int flags,const struct sockaddr_in *dest_addr, socklen_t addrlen)
{
	int ret=0;
	char cBuf[SIZE+2];
	unackd *ptr;
	
		P(unackSem);
		cBuf[0]='1';
		cBuf[1]=++ackCounter;
		strcpy(&cBuf[2],(char*)buf);
///**/						printf("snt-->%c%d%s\n",*cBuf,cBuf[1],cBuf+2);
		ptr=unackdBuff;
		if(unackdBuff==NULL)
			ptr=unackdBuff=(unackd*)malloc(sizeof(unackd));
			else
			{
				while(ptr->next!=NULL)
				ptr=ptr->next;
				ptr->next=(unackd*)malloc(sizeof(unackd));
				ptr=ptr->next;
			}
			
		ret+=sendto(sockfd,cBuf,strlen(cBuf)+1,flags,(struct sockaddr*)dest_addr,addrlen);
		
		gettimeofday(&ptr->timestamp,NULL);
		strcpy(ptr->packet,cBuf+1);
		strcpy(ptr->addr,inet_ntoa(dest_addr->sin_addr));
		ptr->portno=ntohs(dest_addr->sin_port);
		ptr->next=NULL;
		V(unackSem);	
	return ret;
}

