//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>

#include"rsock.h"


/*
		This function opens an UDP socket with the socket call. It also creates the
	2 threads R and S, and allocates initial space for the tables. The parameters to these
	are the same as the normal socket( ) call, except that it will take only SOCK_MRP as
	the socket type.
*/
int r_socket(int domain, int type, int protocol)
{
	key_t key1,key2;
	
		if(type!=SOCK_MRP)
		{
			fprintf(stderr,"r_socket:type supposed to be SOCK_MRP:");
			return -1;
		}
		if((sockfd = socket(domain,SOCK_DGRAM,0))<0)
		{
			return sockfd;
		}
	
		key1=ftok("/tmp/",8);
		key2=ftok("/tmp/",7);
		unackSem = semget(key1, 1, 0777|IPC_CREAT);
		recvSem = semget(key2, 1, 0777|IPC_CREAT);
	
		semctl(recvSem, 0, SETVAL, 1);
		semctl(unackSem, 0, SETVAL, 1);
	
		pop.sem_num = vop.sem_num = 0;
		pop.sem_flg = vop.sem_flg = 0;
		pop.sem_op = -1 ; vop.sem_op = 1 ;
		
		pthread_create(&R,NULL,receive_routine,NULL);
		pthread_create(&S,NULL,send_routine,NULL);
		

	return sockfd;

}

/*
		The thread S/send_routine behaves in the following manner. It sleeps for some time (T), and wakes up
	periodically. On waking up, it scans the unacknowledged-message table to see if any of
	the messages timeout period (set to 2T ) is over (from the difference between the time in
	the table entry for a message and the current time). If yes, it retransmits that message and
	resets the time in that entry of the table to the new sending time. If not, no action is taken.
	This is repeated for all messages in the table every time S wakes up.
*/
void* send_routine(void* arg)
{
	int i;
	unackd *ptr;
	char buf[SIZE];
	struct sockaddr_in sAddress;
	struct timeval now;

	pth[0]=pthread_self();
	
	while(1)
	{
		i=0;
		usleep(150000);
		P(unackSem);
			ptr=unackdBuff;
			while(ptr!=NULL)
			{
				gettimeofday(&now,NULL);
				if(timevaldiff(&ptr->timestamp,&now)>=300)
				{
					gettimeofday(&ptr->timestamp,NULL);

					sAddress.sin_family = AF_INET;
					sAddress.sin_addr.s_addr = inet_addr(ptr->addr);
					sAddress.sin_port = htons(ptr->portno);
					
					buf[0]='1';
					strcpy(&buf[1],ptr->packet);
					
					sendto(sockfd,buf,strlen(buf)+1,0,(struct sockaddr*)&sAddress,sizeof(sAddress));
///**/								printf("Resend:: (%d)%s\n",buf[1],buf+2);
				
				}
				ptr=ptr->next;
			}
			
		V(unackSem);
	}

}




/*
		The thread R/receive_routine behaves in the following manner. When it receives a message, if 
	it is a data message, it stores it in the received-message table, and sends an ACK message to the
	sender. If it is an ACK message in response to a previously sent message, it updates the
	unacknowledged-message table to take out the message for which the acknowledgement
	has arrived.

*/
void* receive_routine(void* arg)
{
	socklen_t length;
	unackd *ptr,*prev;
	recvd *ptr1;
	char pack[SIZE],ack[2];
	struct sockaddr_in cAddress;

	length=sizeof(cAddress);
	pth[1]=pthread_self();
	while(1)
	{
		recvfrom(sockfd,pack,SIZE, 0,(struct sockaddr *)&cAddress, &length);
		
		switch(pack[0])
		{
			case '0':
				P(unackSem);
					
					prev=ptr=unackdBuff;
					while(ptr!=NULL)
					{
						if(ptr->packet[0]==pack[1])	
						{
							ackCounter--;
///**/										printf("\nackCounter now%d\n",ackCounter);
						/*	if(!(ackCounter-1))
							{
								unackdBuff=NULL;
								cAddress.sin_family = AF_INET;
								cAddress.sin_addr.s_addr = inet_addr(IP);
								cAddress.sin_port = htons(PORT);
								pack[0]='1';pack[1]=255;pack[2]='\0';
								sendto(sockfd,pack,strlen(pack)+1,0,(struct sockaddr*)&cAddress,sizeof(cAddress));
							}
						*/	
							if(ptr==unackdBuff)
							unackdBuff=unackdBuff->next;
							else
							prev->next=ptr->next;
///**/										printf("ack recved:: %d\n",pack[1]);
							free(ptr);
							break;
						}
						prev=ptr;
						ptr=ptr->next;
					}
				V(unackSem);
				break;
			case '1':
				P(recvSem);
					ptr1=recvdBuff;
					if(recvdBuff==NULL)
					ptr1=recvdBuff=(recvd*)malloc(sizeof(recvd));
					else
					{
						while(ptr1->next!=NULL)
						ptr1=ptr1->next;
						
						ptr1->next=(recvd*)malloc(sizeof(recvd));
						ptr1=ptr1->next;
					}
///**/									printf("data received---%c\n",pack[2]);
									printf("%s",pack+2);
					strcpy(ptr1->packet,pack+2);
					strcpy(ptr1->addr,inet_ntoa(cAddress.sin_addr));
					ptr1->portno=ntohs(cAddress.sin_port);
					ptr1->next=NULL;
				V(recvSem);
				ack[0]='0';
				ack[1]=pack[1];
				if(dropMessage()>=500)
					{
						sendto(sockfd,ack,2,0,(struct sockaddr*)&cAddress,sizeof(cAddress));
///**/									printf("ack send:: %d\n",ack[1]);
					}
///**/									else printf("dropped ack:: %d\n",ack[1]);
				break;
		
		}
	}

}
