//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>

#include"rsock.h"



/*
signal handler for ctrl+c
*/
void sigInt()
{
	printf("\nCtrl+C...\n");
	r_close(sockfd);
	exit(0);
}


//////////////////////////
///// MAIN FUNCTION //////
//////////////////////////

int main()
{
	char cBuff[SIZE]="ABCDEFGHIJKLMNOPQRSTUVWXYZ",temp[2];
	socklen_t length;
	int i,len;
	struct sockaddr_in cAddress,sAddress;
	
	signal(SIGINT,sigInt);
	
	if((sockfd=r_socket(AF_INET,SOCK_MRP,0))<0)
	{
		perror("SocketError");
		exit(0);
	}
	printf("Socket Created\n");
	
	sAddress.sin_family = AF_INET;					//setting values
	sAddress.sin_addr.s_addr = inet_addr(IP);
	sAddress.sin_port = htons(PORT);
	
	length=sizeof(cAddress);
	len=strlen(cBuff);
	for(i=0;i<len;i++)
	{
		temp[0]=cBuff[i];
		temp[1]='\0';
		r_sendto(sockfd, temp,2, 0,&sAddress, sizeof(sAddress));
	}
//	r_sendto(sockfd, cBuff,strlen(cBuff), 0,&sAddress, sizeof(sAddress));
//	strcpy(cBuff,"hi second string");
//	r_sendto(sockfd, cBuff, strlen(cBuff), 0,&sAddress, sizeof(sAddress));
//	printf("\t\tData sent:: %s\n",cBuff);
/*	printf("waiting to recv...............\n");
	r_recvfrom(sockfd, cBuff, SIZE, 0,&sAddress, &length);		//receipt reply msg
	printf("\n\tData Received:: %s\n",cBuff);
	
*/	
//	pthread_join(R,NULL);
//	pthread_join(S,NULL);
	wait();
	return 1;
//	r_close(sockfd);

}
