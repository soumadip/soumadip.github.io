//Author:: Soumadip Biswas
//Roll No:: 10IT60R12
//Assignment 3

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<sys/ipc.h>
#include<sys/sem.h>
#include<sys/shm.h>
#include<pthread.h>
#include<sys/socket.h> 
#include<netinet/in.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<sys/time.h>
#include<signal.h>

#include"rsock.h"



/*
signal handler for ctrl+c
*/
void sigInt()
{
	printf("\nCtrl+C...\n");
	r_close(sockfd);
	exit(0);
}


//////////////////////////
///// MAIN FUNCTION //////
//////////////////////////

int main()
{
	char cBuff[SIZE]="";
	socklen_t length;
	struct sockaddr_in cAddress,sAddress;
	
	signal(SIGINT,sigInt);
	
	if((sockfd=r_socket(AF_INET,SOCK_MRP,0))<0)
	{
		perror("SocketError");
		exit(0);
	}
	printf("Socket Created\n");
	
	sAddress.sin_family = AF_INET;					//setting values
	sAddress.sin_addr.s_addr = INADDR_ANY;
	sAddress.sin_port = htons(PORT);
	
	if(r_bind(sockfd,(struct sockaddr*)&sAddress,sizeof(sAddress)) < 0)	//binding
	{
		perror("BindError");
		exit(0);
	}
	printf("Binding Done\n");
	
	length=sizeof(cAddress);
	r_recvfrom(sockfd, cBuff, SIZE, 0,&cAddress, &length);		//receipt msg from client
	printf("\n\tData Received:: %s\n",cBuff);
	
	strcpy(cBuff,"received your data..");
/*	printf("sending reply started..............\n");
	for(i=0;i<=len;i++)
	{
		temp[0]=cBuff[i];
		temp[1]='\0';
		r_sendto(sockfd, temp,2, 0,&cAddress, sizeof(cAddress));
	}
//	r_sendto(sockfd, cBuff, strlen(cBuff), 0,&cAddress, sizeof(cAddress));
*/	
//	pthread_join(R,NULL);
//	pthread_join(S,NULL);
	wait();
	return 1;
//	r_close(sockfd);

}

