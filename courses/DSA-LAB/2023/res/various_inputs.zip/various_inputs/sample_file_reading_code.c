#include<stdio.h>

int main ()
{
	FILE* fp;
	fp = fopen("sample_filename.txt", "r");
	
	int num;
	while (!feof(fp))
	{
		fscanf(fp, "%d\n", &num);
		printf("%d ", num);
	}
	fclose(fp);
}