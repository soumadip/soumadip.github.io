// User defined Package //
    package MyPackage;
    public class MyClass {
      public void test ( ) {
            System.out.println ( " Welcome to My Class !");
      }
    }

