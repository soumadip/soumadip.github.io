// Edit the following program as HelloNoClass.java
class HelloNoClass{      public static void main (String args[ ] ) {
            System.out.println( "Hello Classless Java!");
      }
}
