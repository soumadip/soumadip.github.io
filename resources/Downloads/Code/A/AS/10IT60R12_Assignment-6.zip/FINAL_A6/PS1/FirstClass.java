// Application with more than one classes   //
//   Edit PeopleApplin.java
      class FirstClass {
          int idNo;
          idNo = 555;
          public static void print( ) {
             System.out.println ("First Class citizen"+ idNo );
          }
      }

