// An Application without any class and inputs are passed as command line
// Edit the program as HelloCommandLine.java
class HelloCommandLine{      public static void main(String args[ ] ) {
          for(int i = 0; i < 3;i++)
            System.out.println( "Hello "+ args[i]);
      }
}
