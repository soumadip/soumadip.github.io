/*
 * One more simple Java Application *
 * This application computes square root *
*/
// This is also a comment (one line comment)
import java.lang.Math;
class SquareRoot
{
    public static void main (String args[ ]) {
      double x = 45;     // Variable declaration and initialization
      double y;    // Declaration of another variable
      y = Math.sqrt(x);
      System.out.println("Square root of "+ x +"=" + y);
    }
}

