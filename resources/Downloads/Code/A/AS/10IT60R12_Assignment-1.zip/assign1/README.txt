this programs are only done on given problems  as a solutions
there is no exception checking e.g. enter char instead integer, etc.
so please input carefully
and for the file related program no of input in a file should be calculated manually and should be gieven to 
the program while running.file names should not be changed as it is not written as a command line input program.
thank you.